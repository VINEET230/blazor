﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BlazorApp2.Server.Models;
using Microsoft.AspNetCore.Mvc;
using BlazorApp2.Shared.Models;
using BlazorApp2.Server.Models.IRepository;

namespace BlazorApp2.Server.Controllers
{
    [Route("api/[controller]")]
    public class EmployeeController : Controller
    {
        private IEmployeeDataAccessLayer _empInterface;
        public EmployeeController(IEmployeeDataAccessLayer empInterface)
        {
            _empInterface = empInterface;
        }

        [HttpGet("[action]")]
        [Route("api/Employee/Index")]
        public List<EmployeeModel> Index()
        {
            return _empInterface.GetAllEmployees();
        }

        [HttpPost("[action]")]
        [Route("api/Employee/Create")]
        public void Create([FromBody] EmployeeModel employee)
        {
            if (ModelState.IsValid)
                _empInterface.AddEmployee(employee);
        }

        [HttpPost("[action]")]
        [Route("api/Employee/Details")]
        public EmployeeModel Details([FromBody] EmployeeModel employee)
        {
            return _empInterface.GetEmployeeData(employee.Id);
        }

        [HttpPost("[action]")]
        [Route("api/Employee/Edit")]
        public void Edit([FromBody]EmployeeModel employee)
        {
            if (ModelState.IsValid)
                _empInterface.UpdateEmployee(employee);
        }

        [HttpDelete("[action]")]
        [Route("api/Employee/Delete/{id}")]
        public void Delete(int id)
        {
            _empInterface.DeleteEmployee(id);
        }

    }
}