﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace BlazorApp2.Server.Models
{
    public partial class XANSAONEContext : DbContext
    {
        public XANSAONEContext()
        {
        }

        public XANSAONEContext(DbContextOptions<XANSAONEContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Employee> Employee { get; set; }
        public virtual DbSet<Employee_Details> EmployeeDetails { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server= 10.135.0.241;Database=XANSAONE;user id= sa;password= Steria@123;Trusted_Connection=false;MultipleActiveResultSets=true");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.6-servicing-10079");

            modelBuilder.Entity<Employee>(entity =>
            {
                entity.ToTable("EMPLOYEE");

                entity.HasIndex(e => e.BusinessLeader)
                    .HasName("IX_BUSINESS_LEADER");

                entity.HasIndex(e => e.EmployeeCode)
                    .HasName("IX_EMPLOYEE")
                    .IsUnique();

                entity.HasIndex(e => e.XoneId)
                    .HasName("NonClusteredIndex-20171018-104734");

                entity.HasIndex(e => new { e.EmployeeId, e.HireDate, e.LastDateWork, e.Emp2 })
                    .HasName("EMPLOYEE_Emp2_EMPLOYEE_ID");

                entity.HasIndex(e => new { e.EmployeeId, e.EmployeeCode, e.HireDate, e.Status, e.Emp2 })
                    .HasName("Employee_Emp2");

                entity.HasIndex(e => new { e.EmployeeId, e.EmployeeCode, e.LastName, e.FirstName, e.HireDate, e.ResignationDate, e.LastDateWork, e.Status })
                    .HasName("Employee_Status_EMPLOYEE_CODE_etc, sysname,>");

                entity.HasIndex(e => new { e.EmployeeId, e.EmployeeCode, e.LastName, e.MiddleName, e.FirstName, e.CompteCode, e.Status, e.Emp2 })
                    .HasName("EMPLOYEE_Emp2_COMPTE_CODE");

                entity.HasIndex(e => new { e.EmployeeId, e.EmployeeCode, e.LastName, e.MiddleName, e.FirstName, e.HireDate, e.BirthDate, e.XoneId, e.BusinessLeader, e.Status })
                    .HasName("EMPLOYEE_ID_EMPLOYEE_CODE");

                entity.Property(e => e.EmployeeId).HasColumnName("EMPLOYEE_ID");

                entity.Property(e => e.AadharNumber)
                    .HasColumnName("AADHAR_NUMBER")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.AgeStatus).HasColumnName("AGE_STATUS");

                entity.Property(e => e.AltEcode)
                    .HasColumnName("ALT_ECODE")
                    .HasMaxLength(7)
                    .IsUnicode(false);

                entity.Property(e => e.AssignmentManager).HasColumnName("ASSIGNMENT_MANAGER");

                entity.Property(e => e.AttendanceOnly).HasDefaultValueSql(@"
/****** Object: Default [True]  ******/
create default [True] as 1
");

                entity.Property(e => e.AvailabilityStatus).HasColumnName("AVAILABILITY_STATUS");

                entity.Property(e => e.BenifitRecordNo).HasColumnName("BENIFIT_RECORD_NO");

                entity.Property(e => e.BirthCountryId).HasColumnName("BIRTH_COUNTRY_ID");

                entity.Property(e => e.BirthDate)
                    .HasColumnName("BIRTH_DATE")
                    .HasColumnType("datetime");

                entity.Property(e => e.BirthPlace)
                    .HasColumnName("BIRTH_PLACE")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.BirthStateId).HasColumnName("BIRTH_STATE_ID");

                entity.Property(e => e.BusinessLeader).HasColumnName("BUSINESS_LEADER");

                entity.Property(e => e.BusinessTitle)
                    .HasColumnName("BUSINESS_TITLE")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.CareerManager).HasColumnName("CAREER_MANAGER");

                entity.Property(e => e.CitizenshipStatusId).HasColumnName("CITIZENSHIP_STATUS_ID");

                entity.Property(e => e.CompanySeniorityDate)
                    .HasColumnName("COMPANY_SENIORITY_DATE")
                    .HasColumnType("datetime");

                entity.Property(e => e.CompteCode).HasColumnName("COMPTE_CODE");

                entity.Property(e => e.ConfirmationDateEmp)
                    .HasColumnName("CONFIRMATION_DATE_EMP")
                    .HasColumnType("datetime");

                entity.Property(e => e.Confirmed).HasColumnName("CONFIRMED");

                entity.Property(e => e.CreationBy)
                    .HasColumnName("CREATION_BY")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.CreationOn)
                    .HasColumnName("CREATION_ON")
                    .HasColumnType("datetime");

                entity.Property(e => e.DateLastIncrease)
                    .HasColumnName("DATE_LAST_INCREASE")
                    .HasColumnType("datetime");

                entity.Property(e => e.DeathDate)
                    .HasColumnName("DEATH_DATE")
                    .HasColumnType("datetime");

                entity.Property(e => e.Emp2).HasDefaultValueSql("((0))");

                entity.Property(e => e.EmployeeCode)
                    .IsRequired()
                    .HasColumnName("EMPLOYEE_CODE")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.EmploymentStatusId).HasColumnName("EMPLOYMENT_STATUS_ID");

                entity.Property(e => e.EmploymentTypeId).HasColumnName("EMPLOYMENT_TYPE_ID");

                entity.Property(e => e.ExpectedReturnDate)
                    .HasColumnName("EXPECTED_RETURN_DATE")
                    .HasColumnType("datetime");

                entity.Property(e => e.FatherName)
                    .HasColumnName("FATHER_NAME")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.FirstName)
                    .IsRequired()
                    .HasColumnName("FIRST_NAME")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FtStudent).HasColumnName("FT_STUDENT");

                entity.Property(e => e.HighestEduLevelId).HasColumnName("HIGHEST_EDU_LEVEL_ID");

                entity.Property(e => e.HighlyCompEmplC).HasColumnName("HIGHLY_COMP_EMPL_C");

                entity.Property(e => e.HighlyCompEmplP).HasColumnName("HIGHLY_COMP_EMPL_P");

                entity.Property(e => e.HireDate)
                    .HasColumnName("HIRE_DATE")
                    .HasColumnType("datetime");

                entity.Property(e => e.HomeHostId).HasColumnName("HOME_HOST_ID");

                entity.Property(e => e.HomePracticeManagerId).HasColumnName("HOME_PRACTICE_MANAGER_ID");

                entity.Property(e => e.LanguageCode).HasColumnName("LANGUAGE_CODE");

                entity.Property(e => e.LastDateWork)
                    .HasColumnName("LAST_DATE_WORK")
                    .HasColumnType("datetime");

                entity.Property(e => e.LastName)
                    .HasColumnName("LAST_NAME")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdatedByusr)
                    .HasColumnName("LAST_UPDATED_BYUSR")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdatedOndt)
                    .HasColumnName("LAST_UPDATED_ONDT")
                    .HasColumnType("datetime");

                entity.Property(e => e.LastVerificationDate)
                    .HasColumnName("LAST_VERIFICATION_DATE")
                    .HasColumnType("datetime");

                entity.Property(e => e.MaritalStatus).HasColumnName("MARITAL_STATUS");

                entity.Property(e => e.MarriageDate)
                    .HasColumnName("MARRIAGE_DATE")
                    .HasColumnType("datetime");

                entity.Property(e => e.MiddleName)
                    .HasColumnName("MIDDLE_NAME")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.MotherName)
                    .HasColumnName("MOTHER_NAME")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.NominatedBusinessLeader).HasColumnName("NOMINATED_BUSINESS_LEADER");

                entity.Property(e => e.OfaEmployeeId)
                    .HasColumnName("OFA_Employee_ID")
                    .HasMaxLength(6)
                    .IsUnicode(false);

                entity.Property(e => e.OtherAddressId).HasColumnName("OTHER_ADDRESS_ID");

                entity.Property(e => e.PermanentAddressId).HasColumnName("PERMANENT_ADDRESS_ID");

                entity.Property(e => e.PhoneId).HasColumnName("PHONE_ID");

                entity.Property(e => e.Prefix)
                    .HasColumnName("PREFIX")
                    .HasMaxLength(7)
                    .IsUnicode(false);

                entity.Property(e => e.ProfExpDate)
                    .HasColumnName("PROF_EXP_DATE")
                    .HasColumnType("datetime");

                entity.Property(e => e.ReferralId).HasColumnName("REFERRAL_ID");

                entity.Property(e => e.RehireDate)
                    .HasColumnName("Rehire_Date")
                    .HasColumnType("datetime");

                entity.Property(e => e.ResignationDate)
                    .HasColumnName("RESIGNATION_DATE")
                    .HasColumnType("datetime");

                entity.Property(e => e.ServiceDate)
                    .HasColumnName("SERVICE_DATE")
                    .HasColumnType("datetime");

                entity.Property(e => e.Sex)
                    .HasColumnName("SEX")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.SpouseName)
                    .HasColumnName("SPOUSE_NAME")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Status).HasColumnName("STATUS");

                entity.Property(e => e.Suffix)
                    .HasColumnName("SUFFIX")
                    .HasMaxLength(7)
                    .IsUnicode(false);

                entity.Property(e => e.Timestamp)
                    .IsRequired()
                    .HasColumnName("TIMESTAMP")
                    .IsRowVersion();

                entity.Property(e => e.WorkPhone)
                    .HasColumnName("WORK_PHONE")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.XoneId)
                    .HasColumnName("XONE_ID")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.YearsOfExperience).HasColumnName("YEARS_OF_EXPERIENCE");

                entity.HasOne(d => d.AssignmentManagerNavigation)
                    .WithMany(p => p.InverseAssignmentManagerNavigation)
                    .HasForeignKey(d => d.AssignmentManager)
                    .HasConstraintName("FK_EMP_EMP_1");

                entity.HasOne(d => d.CareerManagerNavigation)
                    .WithMany(p => p.InverseCareerManagerNavigation)
                    .HasForeignKey(d => d.CareerManager)
                    .HasConstraintName("FK_EMP_EMP");

                entity.HasOne(d => d.HomePracticeManager)
                    .WithMany(p => p.InverseHomePracticeManager)
                    .HasForeignKey(d => d.HomePracticeManagerId)
                    .HasConstraintName("FK_EMP_EMP_3");

                entity.HasOne(d => d.NominatedBusinessLeaderNavigation)
                    .WithMany(p => p.InverseNominatedBusinessLeaderNavigation)
                    .HasForeignKey(d => d.NominatedBusinessLeader)
                    .HasConstraintName("FK_EMP_EMP_2");
            });

            modelBuilder.Entity<Employee_Details>(entity =>
            {
                entity.HasKey(e => e.EmployeeDetailsId)
                    .HasName("PK_ED")
                    .ForSqlServerIsClustered(false);

                entity.ToTable("EMPLOYEE_DETAILS");

                entity.HasIndex(e => e.BusinessUnit)
                    .HasName("NonClusteredIndex-20171018-103004");

                entity.HasIndex(e => e.ContractualLocation)
                    .HasName("NonClusteredIndex-20171018-102950");

                entity.HasIndex(e => e.Email);

                entity.HasIndex(e => e.EmployeeId)
                    .HasName("IX_EMPLOYEE_ID")
                    .IsUnique()
                    .ForSqlServerIsClustered();

                entity.HasIndex(e => e.HomeDepartmentId)
                    .HasName("NonClusteredIndex-20171018-103044");

                entity.HasIndex(e => e.JobCodeId)
                    .HasName("NonClusteredIndex-20171018-102916");

                entity.HasIndex(e => e.WorkforceTypeId)
                    .HasName("NonClusteredIndex-20171018-103033");

                entity.HasIndex(e => new { e.EmployeeId, e.JobCodeId, e.GeogId })
                    .HasName("EMPLOYEE_DETAILS_GEOG_ID_EMPLOYEE_ID_JOB_CODE_ID, sysname,>");

                entity.HasIndex(e => new { e.EmployeeId, e.JobCodeId, e.HomeDepartmentId, e.GeogId })
                    .HasName("EMPLOYEE_DETAILS_GEOG_ID_Job_Code_ID, sysname,>");

                entity.HasIndex(e => new { e.EmployeeId, e.Cug, e.Email, e.JobCodeId, e.ContractualLocation, e.ActualLocation, e.HomeDepartmentId, e.GeogId, e.WorkforceTypeId })
                    .HasName("EMPLOYEE_DETAILS_GEOG_ID_Workforce_Type_ID");

                entity.Property(e => e.EmployeeDetailsId).HasColumnName("EMPLOYEE_DETAILS_ID");

                entity.Property(e => e.AccSocStatus).HasColumnName("ACC_SOC_STATUS");

                entity.Property(e => e.ActionReasonId).HasColumnName("Action_Reason_ID");

                entity.Property(e => e.ActualLocation).HasColumnName("Actual_Location");

                entity.Property(e => e.Band)
                    .HasColumnName("BAND")
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.BankAccountNo)
                    .HasColumnName("Bank_Account_No")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BillabilityId).HasColumnName("BILLABILITY_ID");

                entity.Property(e => e.BloodGroup)
                    .HasColumnName("Blood_Group")
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.BuOriginal).HasColumnName("BU_Original");

                entity.Property(e => e.BusinessUnit).HasColumnName("Business_Unit");

                entity.Property(e => e.CompanyId).HasColumnName("Company_ID");

                entity.Property(e => e.ConfirmationDueDate)
                    .HasColumnName("Confirmation_Due_Date")
                    .HasColumnType("datetime");

                entity.Property(e => e.ContractualLocation).HasColumnName("Contractual_Location");

                entity.Property(e => e.CoreSkillId).HasColumnName("Core_Skill_ID");

                entity.Property(e => e.Cug)
                    .HasColumnName("CUG")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.DeptEntryDate)
                    .HasColumnName("Dept_Entry_Date")
                    .HasColumnType("datetime");

                entity.Property(e => e.DesignationOnJoining)
                    .HasColumnName("DESIGNATION_ON_JOINING")
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.EffectiveDate)
                    .HasColumnName("Effective_date")
                    .HasColumnType("datetime");

                entity.Property(e => e.EffectiveSequence).HasColumnName("Effective_Sequence");

                entity.Property(e => e.Email)
                    .HasColumnName("EMAIL")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.EmpKnownAsName)
                    .HasColumnName("EMP_KNOWN_AS_NAME")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.EmployeeClassMasterId).HasColumnName("EMPLOYEE_CLASS_MASTER_ID");

                entity.Property(e => e.EmployeeId).HasColumnName("EMPLOYEE_ID");

                entity.Property(e => e.FullPartId).HasColumnName("Full_Part_ID");

                entity.Property(e => e.GeogId).HasColumnName("GEOG_ID");

                entity.Property(e => e.HolidayScheduleId).HasColumnName("Holiday_Schedule_ID");

                entity.Property(e => e.HomeCostCenter)
                    .HasColumnName("Home_Cost_Center")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.HomeDepartmentId).HasColumnName("HOME_DEPARTMENT_ID");

                entity.Property(e => e.IndianJobCode)
                    .HasColumnName("INDIAN_JOB_CODE")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.IntConfirmationDueDate)
                    .HasColumnName("IntConfirmation_Due_Date")
                    .HasColumnType("datetime");

                entity.Property(e => e.IntConfirmedDate)
                    .HasColumnName("IntConfirmed_Date")
                    .HasColumnType("datetime");

                entity.Property(e => e.IsBankAcc).HasColumnName("IS_BANK_ACC");

                entity.Property(e => e.JobCodeEntryDate)
                    .HasColumnName("Job_Code_Entry_Date")
                    .HasColumnType("datetime");

                entity.Property(e => e.JobCodeId).HasColumnName("JOB_CODE_ID");

                entity.Property(e => e.JoiningGrade)
                    .HasColumnName("JOINING_GRADE")
                    .HasMaxLength(5)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdatedByusr)
                    .HasColumnName("LAST_UPDATED_BYUSR")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.LastUpdatedOndt)
                    .HasColumnName("LAST_UPDATED_ONDT")
                    .HasColumnType("datetime");

                entity.Property(e => e.NinoNumber)
                    .HasColumnName("NINO_NUMBER")
                    .HasMaxLength(8)
                    .IsUnicode(false);

                entity.Property(e => e.NormalisedMonthsOfExperience).HasColumnName("Normalised_Months_of_Experience");

                entity.Property(e => e.OfficerCode).HasColumnName("Officer_Code");

                entity.Property(e => e.OldEmail)
                    .HasColumnName("Old_Email")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.PanNo)
                    .HasColumnName("Pan_No")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PayGroupId).HasColumnName("Pay_Group_ID");

                entity.Property(e => e.PfAccountNo)
                    .HasColumnName("PF_Account_No")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PfNo)
                    .HasColumnName("PF_NO")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PhdComments)
                    .HasColumnName("PHD_COMMENTS")
                    .HasMaxLength(8000)
                    .IsUnicode(false);

                entity.Property(e => e.Position)
                    .HasMaxLength(8)
                    .IsUnicode(false);

                entity.Property(e => e.PracticeSectorId).HasColumnName("Practice_Sector_ID");

                entity.Property(e => e.PreferedEmail)
                    .HasColumnName("Prefered_Email")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.ProfitCenterEffDate)
                    .HasColumnName("Profit_Center_Eff_Date")
                    .HasColumnType("datetime");

                entity.Property(e => e.ReasonId).HasColumnName("Reason_ID");

                entity.Property(e => e.RegularId).HasColumnName("Regular_ID");

                entity.Property(e => e.RegulatoryRegionId).HasColumnName("Regulatory_Region_ID");

                entity.Property(e => e.SalTypeId).HasColumnName("Sal_Type_ID");

                entity.Property(e => e.SectorEffectiveDate)
                    .HasColumnName("Sector_Effective_Date")
                    .HasColumnType("datetime");

                entity.Property(e => e.SkillSet)
                    .HasColumnName("Skill_Set")
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.StandardHour)
                    .HasColumnName("Standard_Hour")
                    .HasColumnType("decimal(18, 2)");

                entity.Property(e => e.TechnicalClassMasterId).HasColumnName("TECHNICAL_CLASS_MASTER_ID");

                entity.Property(e => e.Timestamp)
                    .IsRequired()
                    .HasColumnName("TIMESTAMP")
                    .IsRowVersion();

                entity.Property(e => e.UkAccountName)
                    .HasColumnName("UK_ACCOUNT_NAME")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.UkBankAccNo)
                    .HasColumnName("UK_BANK_ACC_NO")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UkBankName)
                    .HasColumnName("Uk_Bank_Name")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.UkBuilSocRollName)
                    .HasColumnName("UK_BUIL_SOC_ROLL_NAME")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.UkBuilSocRollNo)
                    .HasColumnName("UK_BUIL_SOC_ROLL_NO")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UkBuilSocSocName)
                    .HasColumnName("UK_BUIL_SOC_SOC_NAME")
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.UkSortCode)
                    .HasColumnName("UK_SORT_CODE")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UkSwiftCode)
                    .HasColumnName("Uk_Swift_Code")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.WorkforceTypeId).HasColumnName("Workforce_Type_ID");

                entity.Property(e => e.WorkingHourWeekly).HasColumnName("Working_Hour_weekly");

                entity.HasOne(d => d.Employee)
                    .WithOne(p => p.EmployeeDetails)
                    .HasForeignKey<Employee_Details>(d => d.EmployeeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ED_EMP");
            });
        }
    }
}
