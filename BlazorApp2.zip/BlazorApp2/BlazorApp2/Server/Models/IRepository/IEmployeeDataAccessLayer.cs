﻿using BlazorApp2.Shared.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorApp2.Server.Models.IRepository
{
    public interface IEmployeeDataAccessLayer
    {
        List<EmployeeModel> GetAllEmployees();

        List<BlazorApp2.Shared.Models.Employee> GetListEmployees();

        //To Add new employee record     
        void AddEmployee(EmployeeModel employee);

        //To Update the records of a particluar employee    
        void UpdateEmployee(EmployeeModel employeeModel);

        //Get the details of a particular employee    
        EmployeeModel GetEmployeeData(int id);


        //To Delete the record of a particular employee    
        void DeleteEmployee(int id);

    }
}
