﻿using BlazorApp2.Server.Models.IRepository;
using BlazorApp2.Shared.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorApp2.Server.Models
{
    public class EmployeeDataAccessLayer : IEmployeeDataAccessLayer
    {
        XANSAONEContext db = new XANSAONEContext();

        //To Get all employees details   
        public List<EmployeeModel> GetAllEmployees()
        {
            try
            {
                var data = (from emp in db.Employee
                            join dt in db.EmployeeDetails on emp.EmployeeId equals dt.EmployeeId
                            select new EmployeeModel
                            {
                                Id = emp.EmployeeId,
                                FirstName = emp.FirstName,
                                LastName = emp.LastName,
                                DateOfBirth = emp.BirthDate,
                                Gender = emp.Sex,
                                EMail = dt.Email,
                                IsActive = false
                            }).OrderByDescending(x => x.Id).Take(50).ToList();


                return data;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public List<BlazorApp2.Shared.Models.Employee> GetListEmployees()
        {
            try
            {
                var data = (from emp in db.Employee
                            join dt in db.EmployeeDetails on emp.EmployeeId equals dt.EmployeeId
                            select new BlazorApp2.Shared.Models.Employee
                            {
                                Id = emp.EmployeeId,
                                FirstName = emp.FirstName,
                                LastName = emp.LastName,
                            }).OrderByDescending(x => x.Id).Take(10).ToList();

                return data;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //To Add new employee record     
        public void AddEmployee(EmployeeModel employee)
        {
            try
            {
                Random random = new Random();
                var empCode = random.Next(10000, 9999999);
                Employee emp = new Employee();
                emp.FirstName = employee.FirstName;
                emp.LastName = employee.LastName;
                emp.Status = 1;
                emp.Sex = "F";
                emp.EmployeeCode = empCode.ToString();
                db.Employee.Add(emp);
                db.SaveChanges();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //To Update the records of a particluar employee    
        public void UpdateEmployee(EmployeeModel employeeModel)
        {
            try
            {
                Employee employee = db.Employee.Where(x => x.EmployeeId == employeeModel.Id).FirstOrDefault();
                employee.FirstName = employeeModel.FirstName;
                employee.LastName = employeeModel.LastName;
                db.Entry(employee).State = EntityState.Modified;
                db.SaveChanges();
            }
            catch
            {
                throw;
            }
        }

        //Get the details of a particular employee    
        public EmployeeModel GetEmployeeData(int id)
        {
            try
            {
                Employee employee = db.Employee.Where(x => x.EmployeeId == id).FirstOrDefault();
                EmployeeModel model = new EmployeeModel();
                model.Id = employee.EmployeeId;
                model.FirstName = employee.FirstName;
                model.LastName = employee.LastName;
                model.Salary = 123;
                model.City = "city";
                return model;
            }
            catch
            {
                throw;
            }
        }

        //To Delete the record of a particular employee    
        public void DeleteEmployee(int id)
        {
            try
            {
                Employee emp = db.Employee.Find(id);
                db.Employee.Remove(emp);
                db.SaveChanges();
            }
            catch
            {
                throw;
            }
        }
    }
}
