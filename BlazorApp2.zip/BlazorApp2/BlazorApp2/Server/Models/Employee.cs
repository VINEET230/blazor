﻿using System;
using System.Collections.Generic;

namespace BlazorApp2.Server.Models
{
    public partial class Employee
    {
        public Employee()
        {
            InverseAssignmentManagerNavigation = new HashSet<Employee>();
            InverseCareerManagerNavigation = new HashSet<Employee>();
            InverseHomePracticeManager = new HashSet<Employee>();
            InverseNominatedBusinessLeaderNavigation = new HashSet<Employee>();
        }

        public int EmployeeId { get; set; }
        public string EmployeeCode { get; set; }
        public string AltEcode { get; set; }
        public string Prefix { get; set; }
        public string Suffix { get; set; }
        public string LastName { get; set; }
        public string MiddleName { get; set; }
        public string FirstName { get; set; }
        public DateTime? HireDate { get; set; }
        public DateTime? BirthDate { get; set; }
        public string BirthPlace { get; set; }
        public int? BirthStateId { get; set; }
        public int? BirthCountryId { get; set; }
        public string FatherName { get; set; }
        public string MotherName { get; set; }
        public string SpouseName { get; set; }
        public DateTime? DeathDate { get; set; }
        public int? HighestEduLevelId { get; set; }
        public bool? FtStudent { get; set; }
        public int? ReferralId { get; set; }
        public int? CitizenshipStatusId { get; set; }
        public float? YearsOfExperience { get; set; }
        public bool? HighlyCompEmplP { get; set; }
        public bool? HighlyCompEmplC { get; set; }
        public string Sex { get; set; }
        public bool? AgeStatus { get; set; }
        public int? MaritalStatus { get; set; }
        public DateTime? MarriageDate { get; set; }
        public int? PermanentAddressId { get; set; }
        public int? OtherAddressId { get; set; }
        public int? PhoneId { get; set; }
        public short Status { get; set; }
        public bool? Confirmed { get; set; }
        public int? AssignmentManager { get; set; }
        public int? CareerManager { get; set; }
        public DateTime? ResignationDate { get; set; }
        public string XoneId { get; set; }
        public int? BusinessLeader { get; set; }
        public int? NominatedBusinessLeader { get; set; }
        public DateTime? RehireDate { get; set; }
        public DateTime? CompanySeniorityDate { get; set; }
        public DateTime? ServiceDate { get; set; }
        public DateTime? ProfExpDate { get; set; }
        public DateTime? DateLastIncrease { get; set; }
        public int? BenifitRecordNo { get; set; }
        public string BusinessTitle { get; set; }
        public DateTime? LastDateWork { get; set; }
        public string WorkPhone { get; set; }
        public DateTime? ExpectedReturnDate { get; set; }
        public DateTime? LastVerificationDate { get; set; }
        public int? HomeHostId { get; set; }
        public int? HomePracticeManagerId { get; set; }
        public string CreationBy { get; set; }
        public DateTime? CreationOn { get; set; }
        public int? LanguageCode { get; set; }
        public DateTime? LastUpdatedOndt { get; set; }
        public string LastUpdatedByusr { get; set; }
        public int? EmploymentStatusId { get; set; }
        public DateTime? ConfirmationDateEmp { get; set; }
        public byte[] Timestamp { get; set; }
        public string OfaEmployeeId { get; set; }
        public string AadharNumber { get; set; }
        public int? CompteCode { get; set; }
        public int? AvailabilityStatus { get; set; }
        public int? EmploymentTypeId { get; set; }
        public int? Emp2 { get; set; }
        public bool? AttendanceOnly { get; set; }

        public virtual Employee AssignmentManagerNavigation { get; set; }
        public virtual Employee CareerManagerNavigation { get; set; }
        public virtual Employee HomePracticeManager { get; set; }
        public virtual Employee NominatedBusinessLeaderNavigation { get; set; }
        public virtual Employee_Details EmployeeDetails { get; set; }
        public virtual ICollection<Employee> InverseAssignmentManagerNavigation { get; set; }
        public virtual ICollection<Employee> InverseCareerManagerNavigation { get; set; }
        public virtual ICollection<Employee> InverseHomePracticeManager { get; set; }
        public virtual ICollection<Employee> InverseNominatedBusinessLeaderNavigation { get; set; }
    }
}
