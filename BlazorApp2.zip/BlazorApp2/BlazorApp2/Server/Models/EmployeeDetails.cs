﻿using System;
using System.Collections.Generic;

namespace BlazorApp2.Server.Models
{
    public partial class Employee_Details
    {
        public int EmployeeDetailsId { get; set; }
        public int EmployeeId { get; set; }
        public string Cug { get; set; }
        public string Band { get; set; }
        public string Email { get; set; }
        public short? GeogId { get; set; }
        public int? JobCodeId { get; set; }
        public int? PracticeSectorId { get; set; }
        public int? Department { get; set; }
        public short? ContractualLocation { get; set; }
        public int? BusinessUnit { get; set; }
        public string HomeCostCenter { get; set; }
        public int? WorkforceTypeId { get; set; }
        public string BloodGroup { get; set; }
        public string PanNo { get; set; }
        public string PfAccountNo { get; set; }
        public int? CompanyId { get; set; }
        public int? RegulatoryRegionId { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public int? ActionReasonId { get; set; }
        public int? ReasonId { get; set; }
        public short? ActualLocation { get; set; }
        public int? HomeDepartmentId { get; set; }
        public int? BillabilityId { get; set; }
        public DateTime? JobCodeEntryDate { get; set; }
        public int? RegularId { get; set; }
        public int? FullPartId { get; set; }
        public int? OfficerCode { get; set; }
        public decimal? StandardHour { get; set; }
        public int? PayGroupId { get; set; }
        public int? SalTypeId { get; set; }
        public int? CoreSkillId { get; set; }
        public int? HolidayScheduleId { get; set; }
        public string PreferedEmail { get; set; }
        public int? NormalisedMonthsOfExperience { get; set; }
        public string SkillSet { get; set; }
        public DateTime? DeptEntryDate { get; set; }
        public DateTime? LastUpdatedOndt { get; set; }
        public string LastUpdatedByusr { get; set; }
        public int? EmployeeClassMasterId { get; set; }
        public int? TechnicalClassMasterId { get; set; }
        public bool? IsBankAcc { get; set; }
        public bool? AccSocStatus { get; set; }
        public string UkBankAccNo { get; set; }
        public string UkSortCode { get; set; }
        public string UkAccountName { get; set; }
        public string UkBuilSocRollNo { get; set; }
        public string UkBuilSocRollName { get; set; }
        public string UkBuilSocSocName { get; set; }
        public string NinoNumber { get; set; }
        public string PhdComments { get; set; }
        public string UkSwiftCode { get; set; }
        public string UkBankName { get; set; }
        public string EmpKnownAsName { get; set; }
        public byte[] Timestamp { get; set; }
        public string IndianJobCode { get; set; }
        public DateTime? ProfitCenterEffDate { get; set; }
        public short? EffectiveSequence { get; set; }
        public DateTime? SectorEffectiveDate { get; set; }
        public string Position { get; set; }
        public string OldEmail { get; set; }
        public string BankAccountNo { get; set; }
        public string PfNo { get; set; }
        public string JoiningGrade { get; set; }
        public string DesignationOnJoining { get; set; }
        public DateTime? ConfirmationDueDate { get; set; }
        public DateTime? IntConfirmationDueDate { get; set; }
        public DateTime? IntConfirmedDate { get; set; }
        public int? WorkingHourWeekly { get; set; }
        public int? BuOriginal { get; set; }

        public virtual Employee Employee { get; set; }
    }
}
