﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BlazorApp2.Shared.Models
{
    public class EmployeeModel
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string EMail { get; set; }
        public string City { get; set; }
        public string Zip { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public int? Childrens { get; set; }
        public string Gender { get; set; }
        public decimal Salary { get; set; }
        public bool IsActive { get; set; }
    }
}
